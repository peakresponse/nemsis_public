If using the XSL-based Schematron reference implemention, compiled Schematron schemas (in XSL 
format) will be created in this folder.