Element values for the following were changed to 49 because previous values were throwing schematron fatal errors.
	dConfiguration.01 
	dPersonnel.22  
	ePatient.20
	
eInjury.04 was missing a real value when a PN attribute was present	