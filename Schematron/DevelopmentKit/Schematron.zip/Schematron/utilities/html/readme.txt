XML Stylesheet Language Transformation (XSLT) to transform NEMSIS v3 Schematron to HTML for 
documentation purposes

This product is provided by the NEMSIS TAC, without charge, to facilitate browsing NEMSIS 3 
Schematron files via a user-friendly web-based interface.

This product is intended to be published via a web server.

If this product is used from a local file system, the following adjustments may be needed in your 
web browser:

Google Chrome:
  Exit Chrome and then restart Chrome with the following command line parameter:
  --allow-file-access-from-files

Mozilla Firefox:
  Go to about:config and set security.fileuri.strict_origin_policy to false
